globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/f1b4d49aa9e249c5.js",
    "static/chunks/496427e9ba139dad.js",
    "static/chunks/7d6514a90169e63d.js",
    "static/chunks/d771e4a51c8149a6.js",
    "static/chunks/038885a577901430.js",
    "static/chunks/turbopack-00a130221f83a8f1.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];