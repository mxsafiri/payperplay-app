var R=require("../../chunks/[turbopack]_runtime.js")("server/app/opengraph-image/route.js")
R.c("server/chunks/[root-of-the-server]__f24f91fb._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/_next-internal_server_app_opengraph-image_route_actions_ca3aeb2a.js")
R.m(9191)
module.exports=R.m(9191).exports
