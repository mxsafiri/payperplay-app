var R=require("../../chunks/[turbopack]_runtime.js")("server/app/twitter-image/route.js")
R.c("server/chunks/[root-of-the-server]__c59499d9._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/_next-internal_server_app_twitter-image_route_actions_3c56c007.js")
R.m(53534)
module.exports=R.m(53534).exports
