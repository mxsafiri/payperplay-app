var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.webmanifest/route.js")
R.c("server/chunks/[root-of-the-server]__9c91e315._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/_next-internal_server_app_manifest_webmanifest_route_actions_1bff3fca.js")
R.m(22945)
module.exports=R.m(22945).exports
