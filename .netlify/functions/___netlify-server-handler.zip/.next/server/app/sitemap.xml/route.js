var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__1dc4e560._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/_next-internal_server_app_sitemap_xml_route_actions_12658ace.js")
R.m(83345)
module.exports=R.m(83345).exports
