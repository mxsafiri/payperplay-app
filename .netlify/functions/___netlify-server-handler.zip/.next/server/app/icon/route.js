var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon/route.js")
R.c("server/chunks/[root-of-the-server]__d9fbc1f2._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__09c3bdaf._.js")
R.c("server/chunks/_next-internal_server_app_icon_route_actions_0813c6e9.js")
R.m(58338)
module.exports=R.m(58338).exports
