module.exports=[63683,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_creator_stats_route_actions_b1369809.js.map