module.exports=[35694,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_creator_content_route_actions_88015d24.js.map