module.exports=[95359,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_content_%5Bid%5D_route_actions_ed8c36f6.js.map