module.exports=[62340,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_twitter-image_route_actions_3c56c007.js.map