module.exports=[31145,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_icon_route_actions_0813c6e9.js.map