module.exports=[92049,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_creator_content_%5Bid%5D_route_actions_520fff10.js.map