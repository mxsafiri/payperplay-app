module.exports=[21425,e=>e.a(async(t,a)=>{try{let t=await e.y("next/dist/compiled/@vercel/og/index.node.js");e.n(t),a()}catch(e){a(e)}},!0)];

//# sourceMappingURL=%5Bexternals%5D_next_dist_compiled_%40vercel_og_index_node_055f47ab.js.map