module.exports=[39725,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_content_%5Bid%5D_page_actions_8ca0b93f.js.map