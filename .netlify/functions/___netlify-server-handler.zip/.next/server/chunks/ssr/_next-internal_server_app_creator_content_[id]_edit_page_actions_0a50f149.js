module.exports=[93684,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_creator_content_%5Bid%5D_edit_page_actions_0a50f149.js.map