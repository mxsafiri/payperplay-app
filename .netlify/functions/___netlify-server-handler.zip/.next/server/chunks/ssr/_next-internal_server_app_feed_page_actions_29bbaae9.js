module.exports=[78180,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_feed_page_actions_29bbaae9.js.map