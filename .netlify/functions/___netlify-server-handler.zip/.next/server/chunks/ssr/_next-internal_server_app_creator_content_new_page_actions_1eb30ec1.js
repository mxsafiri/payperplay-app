module.exports=[78177,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_creator_content_new_page_actions_1eb30ec1.js.map