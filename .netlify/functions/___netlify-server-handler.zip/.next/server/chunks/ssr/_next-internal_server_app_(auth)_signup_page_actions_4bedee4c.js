module.exports=[2618,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28auth%29_signup_page_actions_4bedee4c.js.map