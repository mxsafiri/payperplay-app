module.exports=[58795,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_library_page_actions_17cdbd80.js.map