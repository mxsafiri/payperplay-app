module.exports=[51996,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_creator_dashboard_page_actions_0a747b4d.js.map