module.exports=[35980,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_opengraph-image_route_actions_ca3aeb2a.js.map