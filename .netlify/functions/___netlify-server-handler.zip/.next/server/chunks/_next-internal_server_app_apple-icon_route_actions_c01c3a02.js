module.exports=[83885,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_apple-icon_route_actions_c01c3a02.js.map