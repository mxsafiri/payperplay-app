module.exports=[29058,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_manifest_webmanifest_route_actions_1bff3fca.js.map