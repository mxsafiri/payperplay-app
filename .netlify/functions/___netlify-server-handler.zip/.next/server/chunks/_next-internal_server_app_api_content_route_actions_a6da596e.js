module.exports=[64381,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_content_route_actions_a6da596e.js.map